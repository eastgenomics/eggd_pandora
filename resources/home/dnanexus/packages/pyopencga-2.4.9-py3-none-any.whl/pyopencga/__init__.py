"refactoring from from fork pyCGA 7f2e3e404 branch release-1.4.0"
__author__="dev_team@mgviz.org"